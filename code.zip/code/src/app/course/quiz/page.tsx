
type Props = {}

const QuizPage = (props: Props) => {
    return <div>QuizPage</div>
};

export default QuizPage
